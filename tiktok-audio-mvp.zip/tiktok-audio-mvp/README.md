# ClipAudio MVP

Next.js MVP for a creator-authorized TikTok audio extraction service.

## Run
npm install
npm run dev

## Production media worker
The included API validates URLs and permission confirmation but intentionally does not scrape TikTok or bypass platform controls. To enable actual MP3 output, connect `/api/extract` to a media source/API you are authorized to access, then send the permitted source file to an FFmpeg worker (e.g. `ffmpeg -i input.mp4 -vn -codec:a libmp3lame -b:a 192k output.mp3`). Use expiring storage URLs, rate limiting, abuse controls and automatic deletion.

## Before launch
Customize Privacy/Terms/Copyright pages; add contact/about pages and substantial original guides; add analytics/cookie consent where legally required; review TikTok terms and Google Publisher Policies; do not place ads so they can be mistaken for the Extract/Download button.
